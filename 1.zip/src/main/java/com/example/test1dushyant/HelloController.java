package com.example.test1dushyant;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class HelloController {
    public TextField username;
    public TextField password;
    @FXML
    private Label welcomeText;


    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("");
        Integer counter =5;
        String x = "dushyant";
        String y = "123";
        String u = username.getText();
        String p = password.getText();

        if(x.equals(u)&&y.equals(p)) {
            counter--;
            counter=5;
            welcomeText.setText("Login successful");

        }
        if(x.equals(u)&&y!=p) {
            if(counter>0)
            if(counter==0) {

                welcomeText.setText("account locked");
            }else{
                counter--;
                welcomeText.setText(" you have"+counter+"attempt left");

            }
        }
        else{
            welcomeText.setText("Invalid username or password");
        }
    }
}