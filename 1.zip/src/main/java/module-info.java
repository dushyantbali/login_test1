module com.example.test1dushyant {
    requires javafx.controls;
    requires javafx.fxml;

    requires com.almasb.fxgl.all;

    opens com.example.test1dushyant to javafx.fxml;
    exports com.example.test1dushyant;
}